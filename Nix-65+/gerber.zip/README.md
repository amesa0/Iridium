# keyplus spectre

Minimal component, 4x12 grid keyboard

![Image of keyplus spectre](https://rawgit.com/ahtn/keyboard_pcb/master/spectre/spectre.jpg)

## License

[CC-BY-SA](https://creativecommons.org/licenses/by-sa/4.0/)
#   I r i d i u m  
 